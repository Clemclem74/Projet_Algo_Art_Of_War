import XCTest

import ProtocolsTests

var tests = [XCTestCaseEntry]()
tests += ProtocolsTests.allTests()
XCTMain(tests)