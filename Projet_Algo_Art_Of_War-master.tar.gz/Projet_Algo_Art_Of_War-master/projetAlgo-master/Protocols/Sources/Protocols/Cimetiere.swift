//
import Foundation



public class Cimetiere : CimetiereProtocol{
	public typealias TCarte = Carte
    fileprivate var cimetiere:[Carte]
    required init(){
        cimetiere=[]
    }
    
    
    public func ajouterCarte(carte : Carte){
        self.cimetiere.append(carte)
    }
    
    public func nombreOccurence()->Int{
        return self.cimetiere.count
    }
    
    public func estVide()->Bool{
        return self.cimetiere.isEmpty
    }
    
    
}
