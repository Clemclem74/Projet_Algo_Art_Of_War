public class ChampIterator : IteratorProtocol  {
    public var plateau: [[Coordonnee]]
    public var i : Int = 0
    public var j : Int = -1
    
    public init(plateau: ChampDeBataille) {
        self.plateau = plateau.plateau
    }
    
    public func next() -> Coordonnee? {
        let tab = self.plateau
        if self.i >= 1 && self.j >= 2{
            return nil
        }
        else {
            j=j+1
            if j==3{
                i=i+1
                j=0
            }
            return tab[i][j]
        }
    }
}


public class ChampDeBataille : ChampDeBatailleProtocol {
	public typealias TCarte = Carte
	public typealias TCoordonnee = Coordonnee
    	public var plateau: [[Coordonnee]] = [[]]
    
    public required init() {
        var tmp : [Coordonnee] = []
        var tmp2 : [Coordonnee] = []
        var cord = Coordonnee(x:0,y:0)
        tmp.append(cord)
        cord = Coordonnee(x:1,y:0)
        tmp.append(cord)
        cord = Coordonnee(x:2,y:0)
        tmp.append(cord)
        
        cord = Coordonnee(x:0,y:1)
        tmp2.append(cord)
        cord = Coordonnee(x:1,y:1)
        tmp2.append(cord)
        cord = Coordonnee(x:2,y:1)
        tmp2.append(cord)
        self.plateau=[tmp,tmp2]
        
    }
    
    public func makeIterator() -> ChampIterator{
        return ChampIterator(plateau:self)
    }
    
    public func positionLibre(cord : Coordonnee)->Bool{
        return self.plateau[cord.positionY()][cord.positionX()].carte==nil
    }
    
    public func insererCarte(carte : Carte, cord : Coordonnee) {
        if !positionLibre(cord:cord){
            fatalError("Insertion sur une carte non vide")
        }
        self.plateau[cord.positionY()][cord.positionX()].carte=carte
    }
    
    public func supprimerCarte(cord : Coordonnee) {
        if positionLibre(cord:cord){
            fatalError("Suppression d'une case vide")
        }
        self.plateau[cord.positionY()][cord.positionX()].carte = nil
    }
    
    public func avancerCarte(cord : Coordonnee) {
        var cordFinale:Coordonnee
        if cord.positionY() == 0 {
            fatalError("On essaie d'avancer une carte en position avant")
        }
        cordFinale = Coordonnee(x : cord.positionY()-1, y : cord.positionX())
        if !positionLibre(cord:cordFinale){
            fatalError("On essaie d'avancer une carte sur une position non libre")
        }
        let tmp : Carte? = self.plateau[cord.positionY()][cord.positionX()].carte
        self.plateau[cord.positionY()][cord.positionX()].carte = nil
        self.plateau[cord.positionY()-1][cord.positionX()].carte = tmp
    }
    
    public func recupererPosition(carte : Carte?)->Coordonnee {
        guard let carte : Carte = carte else{fatalError("carte vide")}
        var c = -1
        for i in 0 ... 1 {
            for j in 0 ... 2 {
                if self.plateau[i][j].carte != nil{
                    guard let carte2 : Carte = self.plateau[i][j].carte else{fatalError("carte champ vide")}
                    c=carte2.id
                }
                if(carte.id == c){
                    return self.plateau[i][j]
                }
            }
        }
        
        fatalError("La carte n'est pas sur le champs de bataille")
    }
    
    public func champDeBatailleEstVide()->Bool {
        for i in 0 ... 1 {
            for j in 0 ... 2 {
                if(self.plateau[i][j].carte != nil){
                    return false
                }
            }
        }
        return true
    }
}
