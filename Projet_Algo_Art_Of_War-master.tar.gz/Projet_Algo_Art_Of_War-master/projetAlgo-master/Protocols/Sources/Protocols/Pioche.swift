import Foundation

public class PiocheIterator : IteratorProtocol {
    private var pioche: Pioche
    private var i : Int = 0
    
    fileprivate init(pioche: Pioche) {
        self.pioche = pioche
    }
    
    public func next() -> Carte? {
        let l : [Carte] = self.pioche.pioche
        if self.i < 0 || self.i >= self.pioche.nombreOccurence(){
            return nil
        }
        else {
            self.i = self.i+1
            return l[self.i-1]
        }
    }
}

// Type Pioche contient une liste de carte et un itérateur permettant de la parcourir
public class Pioche : PiocheProtocol {
	public typealias PCarte = Carte
    var pioche : [Carte]
    // id 1 : Roi 1
    // id 2 : Roi 2
    // id 3 : Soldat 1
    // id 4 : Soldat 2
    // id 5 : Soldat 3
    // id 6 : Soldat 4
    // id 7 : Soldat 5
    // id 8 : Soldat 6
    // id 9 : Soldat 7
    // id 10 : Soldat 8
    // id 11 : Soldat 9
    // id 12 : Garde 1
    // id 13 : Garde 2
    // id 14 : Garde 3
    // id 15 : Garde 4
    // id 16 : Garde 5
    // id 17 : Garde 6
    // id 18 : Archer 1
    // id 19 : Archer 2
    // id 20 : Archer 3
    // id 21 : Archer 4
    // id 22 : Archer 5
    
    public required init() {
        pioche = []
        var ensemble_cord : [Portee]=[]
        var coord = Portee(x : 0 , y : 1)
        ensemble_cord.append(coord)
        var carte : Carte
        for i in 3 ... 11 {
            carte = Carte(id : i , attaque : 0 , defDefensive : 2 , defOffensive : 1 , etat : etatCarte.Defensif , unite : uniteCarte.Soldat , portee : ensemble_cord)
            self.pioche.append(carte)
        }
        
        for i in 12 ... 17 {
            carte = Carte(id : i , attaque : 1 , defDefensive : 3 , defOffensive : 2 , etat : etatCarte.Defensif , unite : uniteCarte.Garde , portee : ensemble_cord)
            self.pioche.append(carte)
        }
        
        coord = Portee(x : -2 , y : 1)
        ensemble_cord[0] = coord
        coord = Portee(x : -1 , y : 2)
        ensemble_cord.append(coord)
        coord = Portee(x : 1 , y : 2)
        ensemble_cord.append(coord)
        coord = Portee(x : 2 , y : 1)
        ensemble_cord.append(coord)
        
        for i in 18 ... 22 {
            carte = Carte(id : i , attaque : 1 , defDefensive : 2 , defOffensive : 1 , etat : etatCarte.Defensif , unite : uniteCarte.Archer , portee : ensemble_cord)
            self.pioche.append(carte)
        }
    }
    
    
    public func supprimerCarte(){
        if !estVide() {
            self.pioche.remove(at:0)
        }
        else {
            fatalError("Supprimer carte d'une pioche vide")
        }
    }
    
    public func nombreOccurence()->Int {
        return self.pioche.count
    }
    
    public func estVide()->Bool {
        return self.pioche.count == 0
    }
    
    public func makeIterator() -> PiocheIterator{
        return PiocheIterator(pioche:self)
    }
    
    
    public func melangerPioche(){
        self.pioche.shuffle()
    }
}

