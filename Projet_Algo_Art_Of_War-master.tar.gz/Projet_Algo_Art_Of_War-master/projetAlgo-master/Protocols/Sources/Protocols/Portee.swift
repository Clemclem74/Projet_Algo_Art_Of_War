//Definition de la structure Portee, qui correspond a la portee d'une carte. (0,0) correspond a la carte elle meme.
import Foundation

public struct Portee : PorteeProtocol {
    fileprivate var x:Int
    fileprivate var y:Int
    
    public init(x : Int,y : Int){
        self.x=x
        self.y=y
    }
    
    public func positionX()->Int {
        return self.x
    }
    
    public func positionY()->Int {
        return self.y
    }
    
}
