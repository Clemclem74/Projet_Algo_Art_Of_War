import Foundation


public class Coordonnee : CoordonneeProtocol {
    public var x : Int
    public var y : Int
    public var carte : Carte?
    
    public required init(x : Int, y : Int){
        self.x = x
        self.y = y
        self.carte = nil
    }
    
    public func positionX()->Int {
        return self.x
    }
    
    public func positionY()->Int {
        return self.y
    }
    
    //modif spé
    public func retournerCarte()->Carte? {
        if(self.carte==nil) {
            return nil
        }
        else {
            return self.carte
        }
    }
    
    public func lierCarte(carte:Carte){
        self.carte = carte
    }
    
    static func == (c1 : Coordonnee,c2 : Coordonnee) -> Bool {
        return ((c2.x == c1.x) && (c2.y == c1.y))
    }
}

