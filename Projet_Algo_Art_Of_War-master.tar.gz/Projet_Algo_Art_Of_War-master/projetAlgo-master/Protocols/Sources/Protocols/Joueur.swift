public class Joueur : JoueurProtocol {
    public var nom : String
    public var main : Main
    public var champ_de_bataille = ChampDeBataille()
    public var pioche = Pioche()
    public var royaume = Royaume()
    public var cimetiere = Cimetiere()
    
    
    public required init(nom : String, num : Int) {
        self.nom = nom
        self.main=Main(numeroRoi : num)
        self.pioche.melangerPioche()
        for _ in 0 ... 3 {
            self.piocher()
        }
    }
    
    
    public func piocher(){
        if self.pioche.estVide(){
            fatalError("On essaie de piocher dans une pioche vide")
        }
        guard let carte : Carte = self.pioche.pioche.first else{fatalError("pioche vide")}
        main.ajouterCarte(carte : carte)
        self.pioche.supprimerCarte()
    }
    
    public func peutAttaquer()->Bool {
        for coords in self.champ_de_bataille.plateau {
            for coord in coords{
                if coord.carte != nil {
                    guard let carte2 : Carte = coord.carte else{fatalError("Carte vide")}
                    if carte2.etat == etatCarte.Defensif {
                        return true
                    }
                }
            }
        }
        return false
    }
    
    public func compterCarteChampDeBataille() -> Int{
        var cmp : Int = 0
        var ChampIt : ChampIterator
        ChampIt = self.champ_de_bataille.makeIterator()
        while ChampIt.next() != nil {
            if ChampIt.plateau[ChampIt.j][ChampIt.i].carte != nil{
                cmp = cmp + 1
            }
        }
        return cmp
    }
    
    public func deployerCarte(carte : Carte, cord : Coordonnee) {
        if self.main.estVide() {
            fatalError("On veut deployer avec une main vide")
        }
        if cord.positionX()>2 || cord.positionX()<0 {
            fatalError("Coordonne x pas compris entre 0 et 2")
        }
        if cord.positionY()>1 || cord.positionY()<0 {
            fatalError("Coordonne y pas compris entre 0 et 1")
        }
        if !self.champ_de_bataille.positionLibre(cord : cord){
            fatalError("La position n'est pas libre")
        }
        carte.changerEtat(etat : etatCarte.Defensif)
        self.champ_de_bataille.insererCarte(carte : carte, cord : cord)
        self.main.enleverCarte(carte : carte)
    }
    
    
    public func avancerCarte(carte : Carte) {
        let pos: Coordonnee = self.champ_de_bataille.recupererPosition(carte : carte)
        self.champ_de_bataille.avancerCarte(cord : pos)
    }
    
    
    public func recupererChampDeBataille()->ChampDeBataille {
        return self.champ_de_bataille
    }
    
    
    //Modif des spécifs
    public func attaquer(joueuradverse : Joueur ,carteAttaquante : Carte, carteAttaque : Carte)->Bool {
        var AttaqueDefense : Int
        if carteAttaquante.recupererUnite() == uniteCarte.Soldat{
            carteAttaquante.attaque = self.main.nombreOccurence()
        }
        if carteAttaquante.recupererEtat() == etatCarte.Offensif {
            fatalError("On veut attaquer avec une carte déjà en posiion offensive")
        }
        carteAttaquante.changerEtat(etat:etatCarte.Offensif)
        if carteAttaque.recupererEtat() == etatCarte.Defensif {
            AttaqueDefense = carteAttaquante.recupererDefDefensive()
        }
        else {
            AttaqueDefense = carteAttaquante.recupererDefOffensive()
        }
        if carteAttaquante.recupererAttaque() == AttaqueDefense {
            self.capturer(joueuradverse : joueuradverse , carte : carteAttaque)
            return true
        }
        else if (carteAttaquante.recupererAttaque() > AttaqueDefense || carteAttaquante.recupererAttaque() > carteAttaque.recupererSante()) {
            let pos : Coordonnee = joueuradverse.champ_de_bataille.recupererPosition(carte : carteAttaque)
            joueuradverse.champ_de_bataille.supprimerCarte(cord : pos)
            if pos.positionY()==0 {
                let derriere = Coordonnee(x : pos.positionX(), y : pos.positionY()+1)
                if !joueuradverse.champ_de_bataille.positionLibre(cord:derriere){
                    joueuradverse.champ_de_bataille.avancerCarte(cord : derriere)
                }
            }
            self.cimetiere.ajouterCarte(carte:carteAttaque)
            return true
        }
        else {
            carteAttaquante.diminuerSante(attaque : carteAttaquante.recupererAttaque())
            return false
        }
    }
    
    
    
    public func demobiliser(carte : Carte) {
        if self.main.estVide() {
            fatalError("On veut demobiliser une carte avec une main vide")
        }
        //il faudrait vérifier que la carte est bien dans la main mais il faut donc rajouter une fonction dans le type Main
        self.royaume.ajouterCarte(carte : carte)
        self.main.enleverCarte(carte : carte)
    }
    
    private func position_portee(position : Coordonnee, portee : Portee) -> Coordonnee? {
        var cord : Coordonnee
        if (position.positionX()==0 && position.positionY()==0) {
            if (portee.positionY()<1) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==1 ) {
                return nil
            }
            else if (portee.positionX()==(-1) && portee.positionY()==1 ) {
                return nil
            }
            else if (portee.positionX()==0 && portee.positionY()==1 ) {
                cord=Coordonnee(x:2 , y:0)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==1 ) {
                cord=Coordonnee(x:1 , y:0)
                return cord
            }
            else if (portee.positionX()==2 && portee.positionY()==1 ) {
                cord=Coordonnee(x:0 , y:0)
                return cord
            }
            else if (portee.positionX()==(-2) && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==(-1) && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==0 && portee.positionY()==2 ) {
                cord=Coordonnee(x:2 , y:1)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==2 ) {
                cord=Coordonnee(x:1 , y:1)
                return cord
            }
            else if (portee.positionX()==2 && portee.positionY()==2 ) {
                cord=Coordonnee(x:0 , y:1)
                return cord
            }
            
        }
        else if (position.positionX()==1 && position.positionY()==0) {
            if (portee.positionY()<1) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==1 ) {
                return nil
            }
            else if (portee.positionX()==(-1) && portee.positionY()==1 ) {
                cord=Coordonnee(x:2 , y:0)
                return cord
            }
            else if (portee.positionX()==0 && portee.positionY()==1 ) {
                cord=Coordonnee(x:1 , y:0)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==1 ) {
                cord=Coordonnee(x:0 , y:0)
                return cord
            }
            else if (portee.positionX()==2 && portee.positionY()==1 ) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==(-1) && portee.positionY()==2 ) {
                cord=Coordonnee(x:2 , y:1)
                return cord
            }
            else if (portee.positionX()==0 && portee.positionY()==2 ) {
                cord=Coordonnee(x:1 , y:1)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==2 ) {
                cord=Coordonnee(x:0 , y:1)
                return cord
            }
            else if (portee.positionX()==2 && portee.positionY()==2 ) {
                return nil
            }
        }
        else if (position.positionX()==2 && position.positionY()==0) {
            if (portee.positionY()<1) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==1 ) {
                cord=Coordonnee(x:2 , y:0)
                return cord
            }
            else if (portee.positionX()==(-1) && portee.positionY()==1 ) {
                cord=Coordonnee(x:1 , y:0)
                return cord
            }
            else if (portee.positionX()==0 && portee.positionY()==1 ) {
                cord=Coordonnee(x:0 , y:0)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==1 ) {
                return nil
            }
            else if (portee.positionX()==2 && portee.positionY()==1 ) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==2 ) {
                cord=Coordonnee(x:2 , y:1)
                return cord
            }
            else if (portee.positionX()==(-1) && portee.positionY()==2 ) {
                cord=Coordonnee(x:1 , y:1)
                return cord
            }
            else if (portee.positionX()==0 && portee.positionY()==2 ) {
                cord=Coordonnee(x:0 , y:1)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==2 && portee.positionY()==2 ) {
                return nil
            }
            
        }
        else if (position.positionX()==0 && position.positionY()==1) {
            if (portee.positionY()<2) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==(-1) && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==0 && portee.positionY()==2 ) {
                cord=Coordonnee(x:2 , y:0)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==2 ) {
                cord=Coordonnee(x:1 , y:0)
                return cord
            }
            else if (portee.positionX()==2 && portee.positionY()==2 ) {
                cord=Coordonnee(x:0 , y:0)
                return cord
            }
        }
        else if (position.positionX()==1 && position.positionY()==1) {
            if (portee.positionY()<2) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==(-1) && portee.positionY()==2 ) {
                cord=Coordonnee(x:2 , y:0)
                return cord
            }
            else if (portee.positionX()==0 && portee.positionY()==2 ) {
                cord=Coordonnee(x:1 , y:0)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==2 ) {
                cord=Coordonnee(x:1 , y:0)
                return cord
            }
            else if (portee.positionX()==2 && portee.positionY()==2 ) {
                return  nil
            }
        }
        else if (position.positionX()==2 && position.positionY()==1) {
            if (portee.positionY()<2) {
                return nil
            }
            else if (portee.positionX()==(-2) && portee.positionY()==2 ) {
                cord=Coordonnee(x:2 , y:0)
                return cord
            }
            else if (portee.positionX()==(-1) && portee.positionY()==2 ) {
                cord=Coordonnee(x:1 , y:0)
                return cord
            }
            else if (portee.positionX()==0 && portee.positionY()==2 ) {
                cord=Coordonnee(x:0 , y:0)
                return cord
            }
            else if (portee.positionX()==1 && portee.positionY()==2 ) {
                return nil
            }
            else if (portee.positionX()==2 && portee.positionY()==2 ) {
                return nil
            }
        }
        return nil
    }
    
    //Modif des spécif
    public func capturer(joueuradverse : Joueur , carte : Carte){
        let pos : Coordonnee = joueuradverse.champ_de_bataille.recupererPosition(carte : carte)
        joueuradverse.champ_de_bataille.supprimerCarte(cord : pos)
        self.royaume.ajouterCarte(carte : carte)
    }
    
    
    
    public func ciblesDisponible(joueuradverse : Joueur)->[Carte]{
        
        var unites: [Carte]
        var cmp: [Carte]
        var champ_de_bataille_adverse : ChampDeBataille
        var position : Coordonnee
        unites = []
        champ_de_bataille_adverse = joueuradverse.recupererChampDeBataille()
        
        for i in 0 ... 1 {
            for j in 0 ... 2 {
                position = Coordonnee(x:j,y:i)
                if !champ_de_bataille_adverse.positionLibre(cord:position) {
                    guard let c : Carte = champ_de_bataille_adverse.plateau[i][j].carte else{fatalError("erreur cible")}
                    cmp = unitePouvantAttaquer(joueuradverse : joueuradverse, carte : c)
                    if(cmp.count != 0){
                        unites.append(c)
                    }
                    
                }
            }
        }
        return unites
    }
    
    
    
    //Modif specif ? On doit avoir acces au plateau du joueur adverse ?
    public func unitePouvantAttaquer(joueuradverse : Joueur, carte : Carte)->[Carte]{
        
        var champ_de_bataille_adverse : ChampDeBataille
        var champ_de_bataille : ChampDeBataille
        var position_carte : Coordonnee
        var carte_attaquante : Carte
        var unites: [Carte]
        var position:Coordonnee
        
        unites = []
        champ_de_bataille_adverse = joueuradverse.recupererChampDeBataille()
        position_carte = champ_de_bataille_adverse.recupererPosition(carte : carte)
        champ_de_bataille = self.champ_de_bataille
        
        for i in 0 ... 1 {
            for j in 0 ... 2 {
                position = Coordonnee(x:j,y:i)
                if !champ_de_bataille.positionLibre(cord:position) {
                    
                    carte_attaquante = champ_de_bataille.plateau[i][j].carte!;
                    for portee in carte_attaquante.portee{
                        if (position_portee(position : position, portee : portee) != nil) {
                            guard let pos : Coordonnee = position_portee(position : position, portee : portee) else{fatalError("mauvaise coord")}
                            if(pos == position_carte && carte_attaquante.etat == etatCarte.Defensif){
                                unites.append(carte_attaquante)
                            }
                        }
                    }
                }
            }
        }
        return unites
    }
    
    
    
}


