import Foundation
// Type ChampDeBataille est une collection de positions contenant des cartes
//(0,0) correspond à F1
public protocol ChampDeBatailleProtocol : Sequence {
  associatedtype TCarte: CarteProtocol
    associatedtype TCoordonnee: CoordonneeProtocol
	associatedtype ChampIterator : IteratorProtocol
	where ChampIterator.Element == TCoordonnee


  // init:
  // initialisé à vide
  init()

  //insererCarte : ChampDeBataille x Carte x Int x Int
  //pre: la case de doit pas être deja occupé
  //post: une carte est ajouté sur le terrain
    mutating func insererCarte(carte: TCarte, cord : TCoordonnee)

  //supprimerCarte : ChampDeBataille Int x Int
  //pre: la case de doit pas être vide
  //post: une carte est supprimé du champ de bataille
  mutating func supprimerCarte(cord : TCoordonnee)

  //avancerCarte : ChampDeBataille Int x Int
  //les coordonnées en paramètre correspondent aux coordonnée actuel de la carte
  //pre: la carte doit être en position arrière, et la position devant elle doit être libre(vide)
  //post: une carte est avancé au front
  mutating func avancerCarte(cord : TCoordonnee)

  //positionLibre: Int x Int -> Bool
  //les paramètres sont des int correspondant à des coordonnées
  //retourne vrai si les coordonnées ne sont pas prise par une carte, faux sinon
  func positionLibre(cord : TCoordonnee)->Bool

//Cette fonction remplace les deux précédentes
    func recupererPosition(carte : TCarte?)->TCoordonnee
    
    
  // champDeBatailleVide : -> Bool
  // Regarde si il y des cartes sur le champ de bataille
  // Retourne true si la champ de bataille est rempli de nil
  func champDeBatailleEstVide()->Bool


  // makeIterator : ChampBatailleProtocol -> MainIteratorProtocol
  // crée un itérateur sur la collection pour itérer avec for in
  func makeIterator()->ChampIterator
}

