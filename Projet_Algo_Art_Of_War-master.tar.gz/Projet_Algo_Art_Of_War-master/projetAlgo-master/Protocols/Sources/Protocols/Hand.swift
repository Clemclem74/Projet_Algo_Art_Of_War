import Foundation


public class MainIterator : IteratorProtocol{
    var main: Main
    var i : Int = 0
    
    public init(main: Main) {
        self.main = main
    }
    
    public func next() -> Carte? {
        let l : [Carte] = self.main.recupererMain()
        if self.i < 0 || self.i >= self.main.nombreOccurence(){
            return nil
        }
        else {
            self.i = self.i+1
            return l[self.i-1]
        }
    }
}



public class Main : MainProtocol {
    var main : [Carte] = []
    
    
    public required init(numeroRoi : Int){
        self.main = []
        var ensemble_cord : [Portee]=[]
        var coord = Portee(x : -2 , y : 1)
        ensemble_cord.append(coord)
        coord = Portee(x : -1 , y : 1)
        ensemble_cord.append(coord)
        coord = Portee(x : 0 , y : 1)
        ensemble_cord.append(coord)
        coord = Portee(x : 1 , y : 1)
        ensemble_cord.append(coord)
        coord = Portee(x : 2 , y : 1)
        ensemble_cord.append(coord)
        if numeroRoi == 1 {
            coord = Portee(x : 0 , y : 2)
            ensemble_cord.append(coord)
            let Roi = Carte(id : 2, attaque : 1, defDefensive : 5, defOffensive : 4, etat : etatCarte.Defensif, unite : uniteCarte.Roi, portee : ensemble_cord)
            self.main.append(Roi)
        }
        else {
            let Roi = Carte(id : 2, attaque : 1, defDefensive : 5, defOffensive : 4, etat : etatCarte.Defensif, unite : uniteCarte.Roi, portee : ensemble_cord)
            self.main.append(Roi)
        }
    }
    
    
    public func makeIterator() -> MainIterator {
        return MainIterator(main:self)
    }
    
    public func recupererCarte(type : uniteCarte)->Carte? {
        for carte in self.main {
            if carte.recupererUnite() == type {
                return carte
            }
        }
        return nil
    }
    
    
    public func ajouterCarte(carte : Carte) {
        for carte_main in self.main {
            if carte_main.recupererIdCarte() == carte.recupererIdCarte() {
                fatalError("Carte déjà dans la main")
            }
        }
        
        self.main.append(carte)
    }
    
    public func enleverCarte(carte : Carte) {
        var i : Int = 0
        if self.estVide() {
            fatalError("Main Vide")
        }
        for carte_main in self.main {
            if carte_main.recupererIdCarte() == carte.recupererIdCarte() {
                self.main.remove(at : i)
            }
            i = i + 1
        }
    }
    
    public func recupererMain()->[Carte]{
        return self.main
    }
    
    public func nombreOccurence()->Int {
        var nb : Int = 0
        for _ in self.main {
            nb=nb+1
        }
        return nb
    }
    
    public func estVide()->Bool {
        let main = self.main
        if main.count == 0{
            return true
        }
        else {
            return false
        }
    }
    
    
}


