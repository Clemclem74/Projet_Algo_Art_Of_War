import Foundation

public class Carte : CarteProtocol {
	public typealias TPortee = Portee
    public var id: Int
    public var attaque: Int
    public var defDefensive: Int
    public var defOffensive: Int
    public var sante : Int
    public var etat: etatCarte
    public var unite: uniteCarte
    public var portee: [Portee]
    

    public required init(id : Int, attaque : Int, defDefensive : Int, defOffensive : Int, etat : etatCarte, unite : uniteCarte, portee : [Portee]){
        self.id = id
        self.attaque = attaque
        self.defDefensive = defDefensive
        self.defOffensive = defOffensive
        self.sante=self.defDefensive
        self.etat = etat
        self.unite = unite
        self.portee = portee
    }
    
    public func changerEtat(etat: etatCarte){
        self.etat=etat
    }
    
    public func recupererUnite()->uniteCarte{
        return self.unite
    }
    
    public func recupererIdCarte()->Int{
        return self.id
    }
    
    //Rajouté des spécif
    public func recupererEtat()->etatCarte {
        return self.etat
    }
    
    //Rajouté des spécifs
    public func recupererSante()->Int {
        return self.sante
    }
    
    //Rajouté des spécifs
    public func diminuerSante(attaque : Int){
        self.sante = self.sante - attaque
    }
    
    //Rajouté des spécifs
    public func recupererAttaque()->Int{
        return self.attaque
    }
    
    //Rajouté des spécifs
    public func recupererDefDefensive()->Int{
        return self.defDefensive
    }
    
    //Rajouté des spécifs
    public func recupererDefOffensive()->Int{
        return self.defOffensive
    }
    
    static func == (c1 : Carte,c2 : Carte) -> Bool {
        return c1.id == c2.id
    }
}
