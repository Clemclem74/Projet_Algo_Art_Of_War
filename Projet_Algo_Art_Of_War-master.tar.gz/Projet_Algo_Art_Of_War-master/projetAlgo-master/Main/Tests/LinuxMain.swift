import XCTest

import MainTests

var tests = [XCTestCaseEntry]()
tests += MainTests.allTests()
XCTMain(tests)