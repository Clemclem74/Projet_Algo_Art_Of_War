import Protocols

/* ------- Programme Main ------- */

//afficherChampBataile : Joueur
//permet d'afficher le camp d'un joueur
func afficherChampBataile(joueur: Joueur){
    let champ = joueur.recupererChampDeBataille()
    let champIT = champ.makeIterator()
    var element : Coordonnee
    var ligne : String
    print("********************************************")
    while champIT.next() != nil{
        element = champIT.plateau[champIT.i][champIT.j]
        ligne = "carte :"
        if(element.retournerCarte() != nil){
            ligne += " \(element.retournerCarte()!.recupererUnite()) "
        }
        else{
            ligne += "        "
        }
        ligne += "->[" + String(element.positionX()) + ";" + String(element.positionY()) + "]"
        print(ligne)
    }
    print("********************************************")
}


//afficherMain : Joueur
//permet d'afficher la  main d'un joueur
func afficherMain(joueur: Joueur){
    print("**********************************************")
    var ligne : String = ""
    for i in 0 ... joueur.main.nombreOccurence()-1{
        ligne = "\(joueur.main.recupererMain()[i].recupererUnite())" + "(id:" + "\(joueur.main.recupererMain()[i].recupererIdCarte())" + ")"
        print(ligne)
    }
    print(ligne)
    print("********************************************")
    
}


//afficherUnites: [Carte]
//correspond a afficher graphiquement une liste de carte
func afficherUnites(unite: [Carte]){
    print("**********************************************")
    var ligne : String = ""
    for i in 0 ..< unite.count{
        ligne = "\(unite[i].recupererUnite())" + "(id:" + "\(unite[i].recupererIdCarte())" + ")"
        print(ligne)
    }
    print("********************************************")
    
}

//permet de selectionner une coordonnée X et Y
func choisirCoordonneeXY(JoueurSelectionner: Joueur,X : inout Int, Y : inout Int){
    var cord : Coordonnee
    repeat{
        print("Choisissez une coordonnee X:")
        
        if let typed = readLine(){
            if let n = Int(typed){
                X = n
            }
        }
        
        print("Choisissez une coordonnee Y:")
        if let typed = readLine(){
            if let n = Int(typed){
                Y = n
            }
        }
        cord = Coordonnee(x:X,y:Y)
    }while(!(X < 3 && X >= 0 && Y < 2 && Y>=0 && JoueurSelectionner.recupererChampDeBataille().positionLibre(cord:cord)))
}


func choisirTypeCarte()->uniteCarte{
    print("choisissez entre : 1- Soldat 2- Archer 3- Garde")
    var choix = ""
    while(choix != "Soldat" && choix != "Archer" && choix != "Garde"){
        if let typed = readLine(){
            choix = typed
            
        } else {
            print("votre choix est incorrecte")
        }
    }
    
    var type : uniteCarte = uniteCarte.Soldat
    if(choix=="Soldat"){
        type = uniteCarte.Soldat
    }
    else if(choix=="Archer"){
        type = uniteCarte.Archer
    }
    else if(choix=="Garde"){
        type = uniteCarte.Garde
    }
    return type
}

/* Initialisation de la partie */
print("Joueur 1 : Veuillez saisir un nom pour votre joueur : ")
var choix2 : String = ""

if let typed = readLine(){
    choix2=typed
}
var joueur1 = Joueur(nom : choix2, num:1)

print("Joueur 2 : Veuillez saisir un nom pour votre joueur : ")
if let typed = readLine(){
    choix2=typed
}
var joueur2 = Joueur(nom : choix2, num:2)

var joueurGagnant = Joueur(nom : "", num:1)
var partiFini = false
var X : Int = -1
var Y : Int = -1
print("Joueur 1 : veuillez selectionner une carte a mettre au royaume")
afficherMain(joueur : joueur1)

var choix_carte : Carte? = joueur1.main.recupererCarte(type : choisirTypeCarte())
while choix_carte == nil{
    print("Vous ne possedez pas cette carte, veuillez en choisir une autre")
    choix_carte = joueur1.main.recupererCarte(type : choisirTypeCarte())
}
joueur1.demobiliser(carte : choix_carte!)

print("mettre un carte au front")
afficherMain(joueur : joueur1)

choisirCoordonneeXY(JoueurSelectionner: joueur1,X : &X, Y : &Y)
var cord = Coordonnee(x:X,y:Y)
choix_carte = joueur1.main.recupererCarte(type : choisirTypeCarte())
while choix_carte == nil{
    print("Vous ne possedez pas cette carte, veuillez en choisir une autre")
    choix_carte = joueur1.main.recupererCarte(type : choisirTypeCarte())
}
joueur1.deployerCarte(carte : choix_carte!,cord:cord)

print("Joueur 2 : veuillez selectionner (un numero) une carte a mettre au royaume")
afficherMain(joueur : joueur2)
choix_carte = joueur2.main.recupererCarte(type : choisirTypeCarte())
while choix_carte == nil{
    print("Vous ne possedez pas cette carte, veuillez en choisir une autre")
    choix_carte = joueur2.main.recupererCarte(type : choisirTypeCarte())
}
joueur2.demobiliser(carte: choix_carte!)

print("mettre un carte au front")
print(afficherMain(joueur : joueur2))

choisirCoordonneeXY(JoueurSelectionner: joueur2,X : &X, Y : &Y)
cord = Coordonnee(x:X,y:Y)
choix_carte = joueur2.main.recupererCarte(type : choisirTypeCarte())
while choix_carte == nil{
    print("Vous ne possedez pas cette carte, veuillez en choisir une autre")
    choix_carte = joueur2.main.recupererCarte(type : choisirTypeCarte())
}
joueur2.deployerCarte(carte : choix_carte!,cord:cord)





/* Boucle principale du jeu */
var tour=1
var input : Int
var joueurActuel : Joueur
var joueurAdverse : Joueur
var changerCible = false
var cibleMorte = false
var valide = false
var cibleDisponible : [Carte]
var unite : [Carte]
var pouvantAttaquer : Bool
var attaquer : Carte //carte qui est attaqué
var attaquant : Carte //Carte attaquante
var attaque = false //permettant de lancer une attaque
while(!partiFini){
    if(tour%2 == 0){
        joueurActuel = joueur2 //attention le joueur doit être de type réference et non pas de type valeur !!!
        joueurAdverse = joueur1
        print("a toi de jouer joueur 2 !")
        
    } else {
        joueurActuel = joueur1
        joueurAdverse = joueur2
        print("a toi de joueur joueur 1 !")
    }
    /* Mise en position défensive de toutes les cartes du champ de bataille du joueur */
    let champ = joueurActuel.recupererChampDeBataille()
    let champIT = champ.makeIterator()
    var c : Coordonnee
    while champIT.next() != nil{
        c = champIT.plateau[champIT.i][champIT.j]
        if c.carte != nil{
            guard let carte : Carte = c.carte else{fatalError("Carte vide")}
            carte.changerEtat(etat: etatCarte.Defensif)
            //Supprimer la carte avant
            joueurActuel.champ_de_bataille.supprimerCarte(cord : c)
            joueurActuel.champ_de_bataille.insererCarte(carte : carte, cord : c)
        }
    }
    if(joueurActuel.pioche.nombreOccurence()>0){
        joueurActuel.piocher()
        
        /* Si les deux joueurs n'ont plus de carte dans leur pioche, on regarde qui à le plus de carte dans son royaume pour désigner le gagnant*/
    } else if (joueurAdverse.pioche.nombreOccurence() == 0){
        if(joueurActuel.royaume.nombreOccurence()>joueurAdverse.royaume.nombreOccurence()){
            joueurGagnant = joueurActuel
            
        } else {
            joueurGagnant = joueurAdverse
        }
        
        partiFini = true;
        break
        
    }
    print("votre champ de bataille : ")
    afficherChampBataile(joueur: joueurActuel)
    print("champ de bataille adverse : ")
    afficherChampBataile(joueur: joueurAdverse)
    print("votre main : ")
    afficherMain(joueur : joueurActuel)
    var choix:String = ""
    //phase action
    print("Veuillez saisir une action a faire (attaquer / deployer / rien) : ")
    if let typed = readLine(){
        choix=typed
    }
    /* Choix de l'action à faire pour ce tour */
    while(choix != "rien" && choix != "deployer" && choix != "attaquer"){
        print("saisi non valide, veuillez reiterer")
        if let typed = readLine(){
            choix = typed
        }
    }
    /* Choix de ne rien faire */
    if(choix == "rien"){
        print("vous decidez de passer votre tour")
        
        /* Choix d'attaquer l'adversaire */
    }
    else if (choix == "attaquer"){
        //-----------------------------------------------RAJOUTER REMPLISSAGE SANTE CARTES---------------------------------------------------------------------------------------------------------------------------
        attaque = true
        let ensemble_cord : [Portee]=[]
        var attaquer = Carte(id : -1 , attaque : 0 , defDefensive : 0 , defOffensive : 0 , etat : etatCarte.Defensif , unite : uniteCarte.Soldat , portee : ensemble_cord)
        while(attaque){
            
            let pouvantAttaquer : Bool = joueurActuel.peutAttaquer()
            cibleDisponible = joueurActuel.ciblesDisponible(joueuradverse : joueurAdverse)
            if(cibleDisponible.count>0 && pouvantAttaquer){
                afficherUnites(unite: cibleDisponible)
                print("Choisir une cible ou arreter l'attaque avec \"stop\"")
                valide = false
                
                while(!valide){
                    if let typed = readLine(){
                        if let n = Int(typed){
                            input = n
                            if (n>=0 && n<cibleDisponible.count){
                                valide = true
                                attaquer = cibleDisponible[input]
                            }
                            else{
                                print("veuillez choisir une action correcte")
                            }
                            
                        } else if (typed == "stop"){
                            valide = true
                            print("l'attaque est stoppee !")
                            attaque = false
                            
                        } else {
                            print("veuillez choisir une action correcte")
                        }
                    }
                }
                
                if(attaque==true){
                    changerCible = false
                    cibleMorte = false
                    while(changerCible == false && cibleMorte == false){
                        unite = joueurActuel.unitePouvantAttaquer(joueuradverse : joueurAdverse , carte : attaquer) //ne montrer que les soldats qui sont en mode defensif
                        if(unite.count>0){ // Si le joueur possède des cartes capable d'atteindre des cartes ennemis
                            print(afficherUnites(unite: unite))
                            print("Avec quelle carte voulez vous attaquer ? (tapez la position du soldat dans la liste (commence par 0) ou changer de cible ? (tapez \"changer\")")
                            valide=false
                            var changer : String = ""
                            attaquant = cibleDisponible[0]
                            while(!valide){
                                if let typed : String = readLine(){
                                    if (typed == "changer"){
                                        valide = true
                                        changer="changer"
                                    }
                                    else if let n = Int(typed){
                                        input = n
                                        if (n>=0 && n<cibleDisponible.count){
                                            attaquant = cibleDisponible[input]
                                            if(attaquant.etat == etatCarte.Defensif){
                                                valide = true
                                                
                                            }
                                            else {
                                                print("Vous avez deja attaque avec cette carte")
                                            }
                                        }
                                        else{
                                            print("veuillez choisir une action correcte")
                                        }
                                    }
                                }
                            }
                            if(changer == "changer"){
                                print("vous avez choisi de changer de cible")
                                changerCible = true
                            }
                            else if(joueurActuel.attaquer(joueuradverse : joueurAdverse , carteAttaquante: attaquant,carteAttaque: attaquer)){
                                print("La carte attaquee est tombe au combat !")
                                cibleMorte = true
                                if(attaquer.unite == uniteCarte.Roi){
                                    joueurGagnant = joueurActuel
                                    partiFini = true
                                    break
                                }
                                    
                                else if (joueurAdverse.recupererChampDeBataille().champDeBatailleEstVide()){ // Si le joueur adverse n'a plus d'unite sur son champ de bataille
                                    if(joueurAdverse.royaume.nombreOccurence() + joueurAdverse.main.nombreOccurence() < 1){ // Si il n'a plus de carte dans le royaume ni dans la main : effondrement
                                        joueurGagnant = joueurActuel
                                        partiFini = true
                                        break
                                    } 
                                    else { // Si il lui reste au moins une carte dans la main ou dans le royaume : conscription
                                        if(!joueurAdverse.royaume.estVide()){
                                            print(joueurAdverse.nom)
                                            print(" vous etes force a déploye une carte venant de votre royaume, veuillez choisir les coordonnees de deploiement")
                                            choisirCoordonneeXY(JoueurSelectionner: joueurAdverse,X : &X, Y : &Y)
                                            cord = Coordonnee(x:X,y:Y)
                                            
                                            let carte_deployee = joueurAdverse.royaume.royaume[joueurAdverse.royaume.nombreOccurence()-1] 
                                            joueurAdverse.royaume.enleverCarte(carte : carte_deployee)
                                            joueurAdverse.deployerCarte(carte : carte_deployee,cord : cord)
                                            
                                        } 
                                        else {
                                            afficherMain(joueur : joueurActuel)
                                            print(joueurAdverse.nom)
                                            print(" veuillez choisir une carte à deployer")
                                            choisirCoordonneeXY(JoueurSelectionner: joueurAdverse,X : &X, Y : &Y)
                                            cord = Coordonnee(x:X,y:Y)
                                            joueurAdverse.deployerCarte(carte : joueurAdverse.main.recupererCarte(type: choisirTypeCarte())!,cord : cord)
                                            print("carte deployé !")
                                            
                                        }
                                    }
                                }
                            }
                            else {
                                print("veuillez choisir une reponse valide")
                            }
                        }	
                        else {
                            print("aucune unite ne peut attaquer cette cible")
                            changerCible = true
                        }
                        
                    }
                }
                
            }
            else {
                print("il n'y a aucune cible adverse...")
                attaque = false
            }
        }
        
        /* Choix de déployer une carte sur le champ de bataille */
    } 
    else if(choix == "deployer"){
        print("veuillez choisir une carte à deployer")
        choisirCoordonneeXY(JoueurSelectionner: joueurActuel,X : &X, Y : &Y)
        cord = Coordonnee(x:X,y:Y)
        var choix_carte = joueur2.main.recupererCarte(type : choisirTypeCarte())
        while choix_carte == nil{
            print("Vous ne possedez pas cette carte, veuillez en choisir une autre")
            choix_carte = joueur2.main.recupererCarte(type : choisirTypeCarte())
        }
        guard let c:Carte = choix_carte else {fatalError("Carte vide")}
        joueurActuel.deployerCarte(carte : c,cord : cord)
        print("carte deployee !")
    }
    tour = tour+1
}

print(joueurGagnant.nom+" est le gagnant de la partie !")
























