import XCTest

import TestsUnitairesTests

var tests = [XCTestCaseEntry]()
tests += TestsUnitairesTests.allTests()
XCTMain(tests)